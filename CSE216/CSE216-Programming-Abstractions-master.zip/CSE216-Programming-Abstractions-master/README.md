# CSE216-Programming-Abstractions

HWs I did in my programming abstractions class, a class about learning different programming language paradigms



HW1: Functional Programming with OCaml


HW2: Functional Programming/ Object Oriented Programming with Java


HW3: Event driven Programming with Java


HW4: Multi-threading with Java


HW5: Object Oriented Programming with Python
