public interface SurfaceAreaHelper {
    double surfaceArea();
}

