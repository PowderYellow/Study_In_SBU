package geometry;

import java.util.Arrays;
import java.util.List;

/**
 * * @Date: 4/7/23 1:14 AM
 */
public class demo {
    public static void main(String[] args) {

//
//        int[] de={1,2,3,4,5};
//        for (int i:de){
//        }

//        double b=90;
//        System.out.println(Math.sin(Math.PI/4));

//        double com_len=1.0;
//        System.out.println(Math.ceil(com_len));
//
//        List<Integer> inte = new List<>();


//        int[] ints = new int[]{1, 2, 3};

//        Point center = new Point("center", 0, 0);
//        Point east = new Point("east", -1.000, 0.000);
//        Point west = new Point("west", 1.000, -0.000);
//        Point north = new Point("north", -0.000, -1.000);
//        Point south = new Point("south", 0.000, 1.000);
//        RadialGraph g01 = new RadialGraph(center, Arrays.asList(north, south, east, west));
//
//        Point center2 = new Point("center", 0, 0);
//        Point east2 = new Point("east", -1.000, 0.000);
//        Point west2 = new Point("west", 1.000, -0.000);
//        Point north2 = new Point("north", -0.000, -1.000);
//        Point south2 = new Point("south", 0.000, 1.000);
//        RadialGraph g02 = new RadialGraph(center2, Arrays.asList(north2, south2, east2, west2));
//
//        System.out.println(g01.equals(g02));


    }
}

