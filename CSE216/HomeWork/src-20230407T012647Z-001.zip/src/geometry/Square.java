package geometry;

public class Square extends Shape {

    @Override
    public Point center() {
        return null; // TODO: part of the assignment
    }

    @Override
    public Square rotateBy(int degrees) {
        return null; // TODO: part of the assignment
    }

    @Override
    public Shape translateBy(double x, double y) {
        return null; // TODO: part of the assignment
    }

    @Override
    public String toString() {
        return null; // TODO: part of the assignment
    }

    public Square(Point a, Point b, Point c, Point d) {
        // TODO: part of the assignment
    }


}
