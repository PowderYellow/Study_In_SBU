IntelliJ IDEA 2018.3.4 (Community Edition)
Build #IC-183.5429.30, built on January 29, 2019
JRE: 1.8.0_152-release-1343-b26 x86_64
JVM: OpenJDK 64-Bit Server VM by JetBrains s.r.o
macOS 10.14